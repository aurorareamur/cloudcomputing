Tentang
-------

Repo ini berisi source code untuk menampilkan hello + versi dari Node.js di server. Sebelum mengupload atau menjalankan aplikasi ini di setiap modul, update dulu modul yang diperlukan:

$ npm update

Modul-modul yg diperlukan utk modul ini tidak disertakan karena akan memboroskan media penyimpan di repo.
