var n = 0;
var x = 0;

while (n < 5) {
  n ++;
  x += n;
  console.log("Nilai n = " + n);
  console.log("Nilai x = " + x);
}
