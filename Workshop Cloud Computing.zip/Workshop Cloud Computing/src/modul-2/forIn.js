var data = {a:1, b:2, c:3};

for (var iterasi in data) {
  console.log("Nilai dari iterasi " + iterasi + " adalah: " + data[iterasi]);
}
