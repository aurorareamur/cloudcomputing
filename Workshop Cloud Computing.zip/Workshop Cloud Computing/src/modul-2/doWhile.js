var i = 0;
do {
  i += 2;
  console.log(i);
} while (i < 20);
