/*
 * GET bencana listing.
 */

var databaseUrl = "localhost/linkaplikasibencana";
var collections = ["bencana"];
var db = require("mongojs").connect(databaseUrl, collections);

exports.list = function(req, res){

	db.bencana.find(function(err, bencana) {
  	res.render('bencana', {listOfEmployee: bencana, title: 'Daftar Korban Bencana'});
	});

};
