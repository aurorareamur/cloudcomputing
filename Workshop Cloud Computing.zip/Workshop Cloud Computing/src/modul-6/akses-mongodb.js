var databaseUrl = "localhost/linkaplikasibencana";
var collections = ["bencana"];
var db = require("mongojs").connect(databaseUrl, collections);

// cari korban
db.bencana.find({name: "Annisa"}, function(err, bencana) {
  if( err || !bencana) console.log("Tidak ada korban bencana alam  bernama Annisa");
  else bencana.forEach( function(emps) {
    console.log(emps);
  });
});

// simpan data korban baru
db.bencana.save({nama : "Kasmawati", asal : "Sulawesi", jk : "wanita", tahun_lahir : "1991"}, function(err, saved) {
  if( err || !saved ) console.log("Korban 'Kasmawati' gagal disimpan");
  else console.log("Korban nama 'Kasmawati' tersimpan");
});

// update data pegawai
db.bencana.update({name : "Saras"}, {$set: {asal: "Purworejo"}}, function(err, updated) {
  if( err || !updated ) console.log("Data 'Saras' gagal diperbaharui");
  else console.log("Data 'Saras' berhasil diperbaharui");
});


//  
